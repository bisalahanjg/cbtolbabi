<?php
ob_start();
define('API_KEY', '5103783662:AAFw9tvS2BMzEiFhZYn3J8S4AXILItI4l3o');
$admin = "1300045733";
function typing($ch)
{
	return bot('sendChatAction',['chat_id'=>$ch,'action'=>'typing',]);
}

function bot($method,$datas=[]){
	$url = "https://api.telegram.org/bot".API_KEY."/".$method;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
	$res = curl_exec($ch);
	if (curl_error($ch)) {
		var_dump(curl_error($ch));
	}else{
		return json_decode($res);
	}
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$m_id = $message->message_id;
$chat_id = $message->chat->id;
$username = $message->from->username;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$user_id = $message->from->id;
$text = $message->text;
$title_group = $message->chat->title;
$type = $message->chat->type;
$reply=$message->reply_to_message;
$nechtasoz=str_word_count($text);
$nharf = strlen($text);

if ((strpos($text, "!start") === 0)||(strpos($text, "/start") === 0)){
	typing($user_id);

	$read = file_get_contents('user.json');
	$json = json_decode($read,true);

	if($read == null || $read == '' || $read == 'null'){
		$init = [];
		$write = fopen("user.json","w") or die("Cannot write to path");
				 fwrite($write,json_encode($init));
				 fclose($write);
		exit();
	}

	$add = array('chat_id' => $user_id);

	array_unshift($json,$add);
	$put = fopen("user.json","w") or die("Cannot write to path");
	fwrite($put,json_encode($json));
	fclose($put);

	bot('sendmessage',['chat_id'=>$user_id,'text'=>"Hi",]);
}
?>