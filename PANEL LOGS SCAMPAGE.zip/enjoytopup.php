<?php
function gocurl($url){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POST, false);
	$result = curl_exec($ch);
	curl_close($ch);
}

gocurl("https://enjoytopup.com/cron/update_produk");
gocurl("https://enjoytopup.com/cron/cancel_pembelian");
gocurl("https://enjoytopup.com/cron/check_status");
gocurl("https://enjoytopup.com/cron/check_status_reseller");
?>