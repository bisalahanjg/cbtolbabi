<?php
error_reporting(1);
session_start();
require_once('config.php');
require_once('../main.php');
if($boyxd['site_param_on'] == "on") {
    $secret = $boyxd['site_parameter'];
    $password = $_GET[$secret];
    if(!isset($password)) {
        exit(header("location:https://www.duitinaja.com/"));
    }else{
        $_SESSION['admin'] = $password;
        header("location:admin");
    }
}
?>