<?php
$boyxd['title'] = 'BoyXD';
$boyxd['banner'] = 'https://i.ibb.co/vxxZfS7/BoyXD.png';
$boyxd['site_param_on'] = 'on';
$boyxd['site_parameter'] = 'boyxd';
?>